// pages/learn/learn.js
var list = require('../../libs/main-list.js');
var slist = list.Config.faciArray
Page({

  /**
   * 页面的初始数据
   */
  data: {
    latitude: '36.728167',
    longitude: '101.749500',
    name: '青海大学教学楼总览',
    describe: '',
    markers:slist,
    naviHidden:true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  //点击标记点发生

  markerTap: function (data) {
    var that = this;
    that.showMakerInfo(data);
    that.changeMarkerColor(data);
    that.desLocStorage(data.markerId)
  },

  //显示兴趣点信息（包括名称、地址）
  showMakerInfo: function (data) {
    var that = this;
    that.setData({
      name: slist[data.markerId].name,
      describe: slist[data.markerId].desc,
      naviHidden: false,
    });
  },

  //改变标签颜色
  changeMarkerColor: function (data) {
    var that = this;
    var sMarkers = slist;
    for (var j = 0; j < sMarkers.length; j++) {
      if (j == data.markerId) {
        sMarkers[data.markerId].iconPath = "../../img/des.png";
      } else {
        sMarkers[j].iconPath = "../../img/orgin.png";
      }
    }
    that.setData({
      markers: sMarkers
    });
  },

  //获取路线
  getRoute: function () {
    wx.navigateTo({
      url: '../route/route',
    })
  },

  //获取位置
  getDetail:function(){
    wx.navigateTo({
      url: 'room/room',
    })
  },

  getLibrary: function () {
    wx.navigateTo({
      url: 'library/library',
    })
  },

  //存储目的地信息
  desLocStorage: function (i) {
    wx.setStorage({
      key: 'desName',
      data: slist[i].name,
    })
    wx.setStorage({
      key: 'desLoc',
      data: slist[i].longitude + ',' + slist[i].latitude,
    })
  },
})