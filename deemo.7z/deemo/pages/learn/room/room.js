// pages/learn/research/research.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var h=0;
    console.log(h);
    wx.getSystemInfo({
      success: function (res) {
        h = res.windowHeight - 160;
        h /= 2;
        that.setData({
          singleHeight: h,
        })
      }
    });
  },

  getDetail:function(){
    wx.navigateTo({
      url: '../desc/desc',
    })
  }
})