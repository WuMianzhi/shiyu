//index.js
//获取应用实例
const app = getApp()
var amapFile = require('../../libs/amap-wx.js');
var markersData = [];
var desName = [], desLocation = [];

Page({
  data: {
    markers: [],
    latitude: '',
    longitude: '',
    textData: {
      name: '青海大学', desc: '宁大路251号'
    },
    focus: false,
    navi_hidden: true,
  },
  //搜索框点击时，自动聚焦，键盘弹出
  bindButtonTap() {
    this.setData({
      focus: true,
    })
  },
  //页面加载，获取周围地物POI数据
  onLoad: function () {
    var that = this;
    var config = require('../../libs/config.js');
    var key = config.Config.key;
    var myAmapFun = new amapFile.AMapWX({ key: key });

    //获取周围地物POI数据
    myAmapFun.getPoiAround({
      iconPathSelected: '../../img/des.png',
      iconPath: '../../img/orgin.png', //图标路径
      //成功获取周围POI数据
      success: function (data) {
        markersData = data.markers;
        that.setData({
          markers: markersData,
          latitude: markersData[0].latitude,
          longitude: markersData[0].longitude
        });
        if (markersData[0].latitude < 36.721649 || markersData[0].latitude > 36.733859 || markersData[0].longitude < 101.74196 || markersData[0].longitude > 101.756852) {
          wx.showToast({
            title: '您不在青海大学内 ! 部分功能受限', icon: 'none'
          })
        }
      },
      //失败，弹出错误信息
      fail: function (info) {
        wx.showModal({ title: info.errMsg })
      }
    })

  },
  //点击标记点，地图下方显示地物详情
  makertap: function (e) {
    var id = e.markerId;
    var that = this;
    that.showMarkerInfo(markersData, id);//显示地物详情
    that.changeMarkerColor(markersData, id);//改变标签颜色
    that.desLocStorage(id);
  },
  //显示兴趣点信息（包括名称、地址）
  showMarkerInfo: function (data, i) {
    var that = this;
    that.setData({
      textData: {
        name: data[i].name,
        desc: data[i].address
      },
      navi_hidden: false,
    });
    console.log('目的地 id: ' + i + markersData[i].name + ' 经纬度: ' + markersData[i].longitude + ',' + markersData[i].latitude)
  },
  //改变标签颜色
  changeMarkerColor: function (data, i) {
    var that = this;
    var markers = [];
    for (var j = 0; j < data.length; j++) {
      if (j == i) {
        data[j].iconPath = "../../img/des.png";
      } else {
        data[j].iconPath = "../../img/orgin.png";
      }
      markers.push(data[j]);
    }
    that.setData({
      markers: markers
    });
  },
  //存储目的地信息
  desLocStorage: function (i) {
    wx.setStorage({
      key: 'desName',
      data: markersData[i].name,
    })
    wx.setStorage({
      key: 'desLoc',
      data: markersData[i].longitude + ',' + markersData[i].latitude,
    })
  },

  //“去这里”视图点击时，此方法调用，跳转路线规划窗口
  navi_to_routing_page: function (e) {
    var that = this;
    wx.navigateTo({
      url: '../route/route',
      success: function (res) {
        console.log("成功回调");
      },
      fail: function (res) {
        console.log("失败回调");
      }
    })
  },
  //“搜索框”视图点击时，此方法调用，跳转搜索界面
  navi_search_page: function (e) {
    wx.navigateTo({
      url: '../search/search',
    })
  },
  goToStaticMap: function () {
    wx.navigateTo({
      url: '../static_map/staticMap',
    })
  },
  goToEat() {
    wx.navigateTo({
      url: '../eat/eat',
    })
  },
  goToLife() {
    wx.navigateTo({
      url: '../life/life',
    })
  },
  goToLearn() {
    wx.navigateTo({
      url: '../learn/learn',
    })
  },
  goToDo() {
    wx.navigateTo({
      url: '../do/do',
    })
  }

})