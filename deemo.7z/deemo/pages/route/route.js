// pages/index/seerch.js
var amapFile = require('../../libs/amap-wx.js');
const app = getApp()
var name='';
var orginLocation = '',desLocation = '';
var orginLat=0.0,orginLongt=0.0;
var desLat=0.0,desLongt=0.0;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    markers: [{
      iconPath: "../../img/des.png",
      id: 0,
      latitude: 36.650038,
      longitude: 101.766228,
      width: 23,
      height: 23
    }, {
      iconPath: "../../img/orgin.png",
      id: 1,
      latitude: 36.649527,
      longitude: 101.766744,
      width: 24,
      height: 24
    }],

    destination:'预警',
    midLati:0.0,midLongti:0.0,
    cost: '如果你可以看到这句话',
    distance: '那么你的网很差',
    polyline: []
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this; 
    //获取当前位置
    wx.getStorage({
      key: 'userLocation',
      success: function (res) {
        orginLocation = res.data;
        orginLat = parseFloat(orginLocation.split(',')[1]);
        orginLongt = parseFloat(orginLocation.split(',')[0]);
        console.log('原始经纬度 ' + orginLocation);
      },
    })
    //获取目的地信息
    wx.getStorage({
      key: 'desName',
      success: function(res) {
        name = res.data;

        that.setData({
          destination:name,
        });
      },
    })
    
    wx.getStorage({
      key: 'desLoc',
      //成功调用，传递参数等信息
      success: function(res) {
        //获取目的地位置信息
        desLocation=res.data;
        desLat = parseFloat(desLocation.split(',')[1]);
        desLongt = parseFloat(desLocation.split(',')[0]);
        //页面设置
        that.setData({
          //设置地图中心位置
          midLati: (desLat+orginLat)/2.0,
          midLongti: (desLongt+orginLongt)/2.0,
          //设置标记点位置
          markers: [{
            iconPath: "../../img/des.png",
            id: 0,
            latitude: desLat,
            longitude: desLongt,
            width: 23,
            height: 23
          }, {
            iconPath: "../../img/orgin.png",
            id: 1,
            latitude: orginLat,
            longitude: orginLongt,
            width: 24,
            height: 24
          }],
        })

        console.log('目的地信息已收到 ' + desLongt + ',' +desLat);
        
        wx.showModal({
          title: '只提供步行路线',
          content: '多走走吧',
          success(res) {
            if (res.confirm) {
              //进行路线规划
              that.getRoute();
            } else if (res.cancel) {
              wx.navigateBack({
                delta:1
              })
            }
          }
        })
      },
    })
  },

  getRoute:function() {
    var that=this;
    var config = require('../../libs/config.js');
    var key = config.Config.key;
    var myAmapFun = new amapFile.AMapWX({ key: key });
    //获取路线规划信息
    myAmapFun.getWalkingRoute({
      origin: orginLocation,
      destination: desLocation,
      success: function (data) {
        var points = [];
        if (data.paths && data.paths[0] && data.paths[0].steps) {
          var steps = data.paths[0].steps;
          for (var i = 0; i < steps.length; i++) {
            var poLen = steps[i].polyline.split(';');
            for (var j = 0; j < poLen.length; j++) {
              points.push({
                longitude: parseFloat(poLen[j].split(',')[0]),
                latitude: parseFloat(poLen[j].split(',')[1])
              })
            }
          }
        }
        that.setData({
          polyline: [{
            points: points,
            color: "#0091ff",
            width: 6
          }]
        });
        if (data.paths[0] && data.paths[0].distance) {
          that.setData({
            distance: data.paths[0].distance + '米'
          });
        }
        if (data.paths[0] && data.paths[0].duration) {
          that.setData({
            cost: parseInt(data.paths[0].duration / 60) + '分钟'
          });
        }
        console.log('路线规划 successed')
      },
      fail: function (info) {
        console('路线规划 failed')
      }
    })

  }
})