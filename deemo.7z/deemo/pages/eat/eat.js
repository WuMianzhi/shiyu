// pages/eat.js
var list = require('../../libs/main-list.js');
var SelectedList = list.Config.canteenList;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    name:'商户名称',
    des:'商户地址',
    desc:'主要业务',
    displayList:[],
    c:0,
    img1: 'https://qdsptupian-1259115394.cos.ap-chengdu.myqcloud.com/bzf.png',
    img2: 'https://qdsptupian-1259115394.cos.ap-chengdu.myqcloud.com/yd.png',
    img3: 'https://qdsptupian-1259115394.cos.ap-chengdu.myqcloud.com/yd2.png',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          displayArray: list.Config.adList
        })
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        // todo
        that.setData({
          scrollHeight: res.windowHeight - 370,
        })
      }
    });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  goToRandom(){
    wx.navigateTo({
      url: 'random/choice',
    })
  },
  goToMainDetail:function(){
    wx.navigateTo({
      url: 'eating/detail?class=0',
    })
  },
  goToSnackDetail() {
    wx.navigateTo({
      url: 'eating/detail?class=1',
    })
  },
  goToDrinkDetail() {
    wx.navigateTo({
      url: 'eating/detail?class=2',
    })
  },
  goToFruitDetail() {
    wx.navigateTo({
      url: 'eating/detail?class=3',
    })
  },
  //“搜索框”视图点击时，此方法调用，跳转搜索界面
  navi_search_page: function (e) {
    wx.navigateTo({
      url: '../search/search',
    })
  },
})