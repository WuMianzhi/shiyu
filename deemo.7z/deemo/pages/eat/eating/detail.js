// pages/eat/eating/detail.js
var list = require('../../../libs/main-list.js');
var sList = [];
var primeList = [];
Page({

  /**
   * 页面的初始数据
   */
  data: {
    multiArray: [
      ['全部', '早餐', '中餐', '晚餐'],
      ['全部', '米饭', '面食', '杂'],
    ],
    multiIndex: [0, 0],
    sectionHidden: false,
    kind:0,
    min:0,max:7
  },
  onReady() {
    var that = this;
    wx.getSystemInfo({
      success: function(res) {
        that.setData({
          scrollHeight: res.windowHeight - 120,
        })
      }
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    var hidden = true;
    var foodClass = options.class * 1;
    switch (foodClass) {
      case 0:
        primeList = list.Config.canteenList;
        hidden = false;
        break;
      case 1:
        primeList = list.Config.snackList;
        hidden = true;
        break;
      case 2:
        primeList = list.Config.drinkList;
        hidden = true;
        break;
      case 3:
        primeList = list.Config.fruitList;
        hidden = true;
        break;
      case 4:
        primeList = list.Config.dailyList;
        hidden = false;
        break;
      case 5:
        primeList = list.Config.otherList;
        hidden = false;
        break;
    }
    sList = primeList;

    wx.getSystemInfo({
      success: function(res) {
        that.setData({
          fClass: foodClass,
          sectionHidden: hidden,
          displayArray: sList,
        })
      }
    });
  },

  bindMultiPickerChange: function(e) {
    var that = this;
    var ekind=0,emin=0,emax=7;
    //对三餐进行分类
    switch (e.detail.value[0]) {
      //全部
      case 0:
        break;
      //早餐
      case 1:
        ekind = 1;
        break;
      //中餐
      case 2:
        ekind=2;
        break;
      //晚餐
      case 3:
        ekind = 3;
        break;
    };
    //对主营食物进行分类
    switch (e.detail.value[1]) {
      //全部
      case 0:
        emin = 0;
        emax = 7;
        break;
      //快餐
      case 1:
        emin=1;
        emax=3;
        break;
      //米粉/面食
      case 2:
        emin = 3;
        emax = 5;
        break;
      //小炒/盖浇
      case 3:
        emin = 2;
        emax = 4;
        break;
      //火锅/麻辣烫
      case 4:
        emin = 4;
        emax = 6;
        break;
      //其他
      case 4:
        emin = 5;
        emax = 7;
        break;
    };
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      kind:ekind,
      max:emax,
      min:emin,
      multiIndex: e.detail.value,
      displayArray: sList,
    })
  },

  bindMultiPickerColumnChange: function(e) {
    console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    var data = {
      multiArray: this.data.multiArray,
      multiIndex: this.data.multiIndex
    };
    data.multiIndex[e.detail.column] = e.detail.value;
    switch (e.detail.column) {
      case 0:
        switch (data.multiIndex[0]) {
          case 0:
            data.multiArray[1] = ['全部', '米饭', '面食', '杂'];
            break;
          case 1:
            data.multiArray[1] = ['杂'];
            break;
          case 2:
            data.multiArray[1] = ['全部', '快餐', '米粉/面食', '小炒/盖浇', '火锅/麻辣烫','其他'];
            break;
          case 3:
            data.multiArray[1] = ['全部', '快餐', '米粉/面食', '小炒', '盖浇', '火锅/麻辣烫','其他'];
            break;
        }
        data.multiIndex[1] = 0;
        break;
      case 1:
    }
    this.setData(data);
  },
  goToIntro: function() {
    wx.navigateTo({
      url: '../shop/induce',
    })
  },
  //“搜索框”视图点击时，此方法调用，跳转搜索界面
  navi_search_page: function(e) {
    wx.navigateTo({
      url: '../../search/search',
    })
  },

})