// pages/eat/random/choice.js
var list = require('../../../libs/main-list.js');
var SelectedList = list.Config.canteenList;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    location:'青海大学',
    sl:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
   
    that.decisionMaker();

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  decisionMaker:function(){
    var that=this;
    var aLoc='qinghaidaxue'
    var aim=Math.floor(Math.random()*SelectedList.length);
    var f = Math.floor(Math.random() * SelectedList[aim].foodArray.length);
    switch (SelectedList[aim].loc){
      case 1: aLoc='园丁食堂'; break;
      case 2: aLoc = '长悦食堂';break;
      case 3: aLoc = '学生食堂';break;
      case 4: aLoc = '棠梨路'; break;
    };
    console.log(aim);
    that.setData({
      location:aLoc,
      canteen:SelectedList[aim].name,
      food: SelectedList[aim].foodArray[f],
      sl: SelectedList[aim]
  })
  }
})