// pages/index/search/search.js
var amapFile = require('../../libs/amap-wx.js');
var config = require('../../libs/config.js');
var list = require('../../libs/main-list.js');
var lonlat;
var city='西宁';
var desName = [], desLocation = [];

Page({

  /**
   * 页面的初始数据
   */
  data: {
    tips: {},
    currentTab: 0,
    winWidth: 0,
    winHeight: 0,

    canteenArray:[],
    dormArray:[],
    faciArray:[],
    otherArray:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this;
    lonlat = e.lonlat;

    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight,

          canteenArray:list.Config.canteenArray,
          dormArray:list.Config.dormArray,
          faciArray:list.Config.faciArray,
          otherArray:list.Config.otherArray,
        });
      }
    });
  },

  bindInput: function (e) {
    var that = this;
    var keywords = e.detail.value;
    var key = config.Config.key;
    var myAmapFun = new amapFile.AMapWX({ key: key });

    myAmapFun.getInputtips({
      keywords: keywords,
      location: lonlat,
      city: city,
      success: function (data) {
        if (data && data.tips) {
          that.setData({
            tips: data.tips
          });
        }
      }
    })
  },

//tabbar切换模块

  // 滑动切换tab   
  bindChange: function (e) {
    var that = this;
    that.setData({ currentTab: e.detail.current });
  },
  // 点击tab切换
  swichNav: function (e) {
    var that = this;
    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },

//点击列表项

  itemTap:function(e){
    var that=this;
    var name = e.currentTarget.dataset.name;
    var loc = e.currentTarget.dataset.loc;
    console.log(name);
    that.storageDesInfo(name,loc);
    that.gotoRoutePage();
  },

  gotoRoutePage:function(){
    wx.navigateTo({
      url: '../route/route',
      success: function (res) {
        console.log("成功回调");
      },
      fail: function (res) {
        console.log("失败回调");
      }
    })
  },

  storageDesInfo: function (name,location) {
    wx.setStorage({
      key: 'desName',
      data: name,
    })
    wx.setStorage({
      key: 'desLoc',
      data: location,
    })
  },

})