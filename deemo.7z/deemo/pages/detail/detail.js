// pages/detail/detail.js
var list = require('../../libs/main-list.js');
var queList = list.Config.queArray;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    queName: '问题名字',
    content: '解决办法',
    latitude: 36.727445,
    longitude: 101.746973,
    destination: [{
      id: 0, 
      name: '问题名字',
      content: '解决办法',
      latitude: 36.727445,
      longitude: 101.746973,
      iconPath:'../../img/des.png',
      height: 30, width: 30,
      callout: {
        content: '关键地点',
        fontSize: '16',
        borderRadius: '10',
        bgColor: '#ffffff',
        padding: '10',
        display: 'ALWAYS'
      }
    }]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    var key = options.key * 1;
    console.log(queList);
    that.desLocStorage(key);
    that.setData({
      ///destination: queList[key],
      queName: queList[key].name,
      content: queList[key].content,
      latitude: queList[key].latitude,
      longitude: queList[key].longitude,
      destination: [{
        id: 0,
        name: queList[key].keyPlace,
        latitude: queList[key].latitude,
        longitude: queList[key].longitude,
        iconPath: '../../img/des.png',
        height: 30, width: 30,
        callout: {
          content: queList[key].keyPlace,
          fontSize: '16',
          borderRadius: '10',
          bgColor: '#ffffff',
          padding: '10',
          display: 'ALWAYS'
        }
      }],
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  getRoute:function(){
    wx.navigateTo({
      url: '../route/route',
    });
  },

  desLocStorage: function (i) {
    wx.setStorage({
      key: 'desName',
      data: queList[i].keyPlace,
    })
    wx.setStorage({
      key: 'desLoc',
      data: queList[i].longitude + ',' + queList[i].latitude,
    })
  },
})