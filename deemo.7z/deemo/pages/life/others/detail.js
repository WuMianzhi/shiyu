// pages/life/others/detail.js
var list = require('../../../libs/main-list.js');
var sArray = [];
Page({

  /**
   * 页面的初始数据
   */
  data: {
    latitude: '36.730167',
    longitude: '101.750364',
    sList: sArray,
    naviHidden: true,
    name: '青海大学超市总览',
    describe: '',
    pickerClass: ['全部', '打印店', '快递点', '手机营业厅', '其他'],
    index:0,
    kind:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    var intro='';
    var pC=[];
    console.log(options.class)
    switch(options.class){
      case '1':
        sArray = list.Config.mallList;
        intro='青海大学超市总览';
        pC = ['全部'];
        break;
      case '2':
        sArray = list.Config.dailyList;
        intro = '青海大学日化商铺总览';
        pC = ['全部', '理发店', '化妆品店', '其他'];
        break;
      case '3':
        sArray = list.Config.otherList;
        intro = '青海大学其他商铺总览';
        pC = ['全部', '打印店', '快递点', '手机营业厅', '其他'];
        break;
    }
    that.setData({
      pickerClass:pC,
      sList: sArray,
      name:intro,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        // todo
        that.setData({
          scrollHeight: res.windowHeight - 395,
        })
      }
    });
  },

  //“搜索框”视图点击时，此方法调用，跳转搜索界面
  navi_search_page: function (e) {
    wx.navigateTo({
      url: '../../search/search',
    })
  },

  //点击标记点发生
  markerTap: function (data) {
    var that = this;
    that.showMakerInfo(data);
    that.changeMarkerColor(data);
    that.desLocStorage(data.markerId)
  },

  //显示兴趣点信息（包括名称、地址）
  showMakerInfo: function (data) {
    var that = this;
    console.log(data.markerId)
    that.setData({
      name: sArray[data.markerId].name,
      describe: sArray[data.markerId].desc,
      naviHidden: false,
    });
  },

  //改变标签颜色
  changeMarkerColor: function (data) {
    var that = this;
    var sMarkers = sArray;
    for (var j = 0; j < sMarkers.length; j++) {
      if (j == data.markerId) {
        sMarkers[data.markerId].iconPath = "../../../img/des.png";
      } else {
          sMarkers[j].iconPath = "../../../img/orgin.png";
      }
    }
    that.setData({
      sList: sMarkers
    });
  },

  //获取路线
  getRoute: function () {
    wx.navigateTo({
      url: '../../route/route',
    })
  },

  //存储目的地信息
  desLocStorage: function (i) {
    wx.setStorage({
      key: 'desName',
      data: sArray[i].name,
    })
    wx.setStorage({
      key: 'desLoc',
      data: sArray[i].longitude + ',' + sArray[i].latitude,
    })
  },
  //选择器
  bindPickerChange(e) {
    var sMarkers = sArray;
    for (var j = 0; j < sMarkers.length; j++) {
      if (sMarkers[j].class == e.detail.value * 1 || e.detail.value * 1==0) {
        sMarkers[j].hidden = false;
        sMarkers[j].alpha = 0;
      } else {
        sMarkers[j].hidden = true;
      }
    }
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      sList:sMarkers,
      index: e.detail.value,
    })
  },
})