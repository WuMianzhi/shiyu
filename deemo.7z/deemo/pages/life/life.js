// pages/life/life.js
var list = require('../../libs/main-list.js');
var queArray = list.Config.queList;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    queList:queArray,
    hiddenAns: true ,
    img1: 'https://qdsptupian-1259115394.cos.ap-chengdu.myqcloud.com/ch.png',
    img2: 'https://qdsptupian-1259115394.cos.ap-chengdu.myqcloud.com/sloud.png',
    img3: 'https://qdsptupian-1259115394.cos.ap-chengdu.myqcloud.com/football.png',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        // todo
        that.setData({
          scrollHeight: res.windowHeight - 255,
        })
      }
    });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  itemTap:function(){
    var that=this;
    that.setData({
      hiddenAns: 0,
    })
  },
  goToMall:function(){
    var that=this;
    wx.navigateTo({
      url: 'others/detail?class=1',
    })
  },
  goToDorm: function () {
    var that = this;
    wx.navigateTo({
      url: 'dorm/dorm',
    })
  },
    goToDaily: function () {
    var that = this;
    wx.navigateTo({
      url: 'others/detail?class=2',
    })
  },
  goToOthers: function () {
    var that = this;
    wx.navigateTo({
      url: 'others/detail?class=3',
    })
  },
  //“搜索框”视图点击时，此方法调用，跳转搜索界面
  navi_search_page: function (e) {
    wx.navigateTo({
      url: '../search/search',
    })
  },
})