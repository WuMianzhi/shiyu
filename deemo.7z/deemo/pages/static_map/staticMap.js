// pages/static_map/staticMap.js
var amapFile = require('../../libs/amap-wx.js');
var config = require('../../libs/config.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    src:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    wx.showLoading({
      title: '加载中',
    });
    that.staticMap();
    wx.hideLoading();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  staticMap:function(){
    var that = this;
    var key = config.Config.key;
    var myAmapFun = new amapFile.AMapWX({ key: key });

    wx.getSystemInfo({
      success: function (data) {
        var height = 700;
        var width = 600;
        var size = width + "*" + height;
        console.log(size)
        myAmapFun.getStaticmap({
          zoom: 15,
          size: size,
          scale: 2,
          location:  '101.749452,36.728053',
          labels: "施工中,3,0,13,0xFFFFFF,0xBB1E22:101.746064,36.730529;101.746192,36.729015;101.744969,36.724561;101.753021,36.724022",
          success: function (data) {
            that.setData({
              src: data.url
            })
          },
          fail: function (info) {
            wx.showModal({ title: info.errMsg })
          }
        })
      }
    })
  }  
})